// ==== fcn_047b5da0  size 11  blocks 1  call sites 0  data pointers 1
undefined4 fcn_047b5da0(void)
{
    int32_t unaff_EBP;
    undefined4 *unaff_FS_OFFSET;
    int32_t var_18h;
    
    *(undefined4 *)(unaff_EBP + -4) = 0xfffffffe;
    *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0x10);
    return 0;
}

// ==== fcn_047c488f  size 50  blocks 1  call sites 1  data pointers 0
void fcn_047c488f(void)
{
    int32_t arg_4h;
    
    arg_4h = 0;
    fcn_03a4e2e9(0, 0);
    fcn_038e6c48(arg_4h);
    __CxxFrameHandler3();
    return;
}

// ==== fcn_047d000a  size 68  blocks 1  call sites 0  data pointers 1
void __cdecl fcn_047d000a(undefined4 placeholder_0, int32_t arg_8h)
{
    int16_t unaff_BP;
    int16_t unaff_SI;
    undefined2 in_SS;
    int32_t arg_4h;
    
    segment(in_SS, unaff_BP + unaff_SI);
    fcn_03a09616("EXCEPTION", "%s:%d");
    arg_4h = 0;
    sub.msvcr100.dll__CxxThrowException();
    fcn_038e6c48(arg_4h);
    __CxxFrameHandler3();
    return;
}

// ==== fcn_047d30a0  size 26  blocks 1  call sites 1  data pointers 0
// WARNING: Control flow encountered bad instruction data

void __fastcall fcn_047d30a0(int32_t param_1, int32_t param_2)
{
    int32_t in_EAX;
    char *pcVar1;
    char extraout_CL;
    int32_t unaff_EBX;
    undefined in_CF;
    
    *(undefined *)(in_EAX + 0x50) = (char)(CONCAT11(in_CF, *(undefined *)(in_EAX + 0x50)) >> 1);
    *(int32_t *)(param_1 + param_2) = *(int32_t *)(param_1 + param_2) >> ((uint8_t)param_1 & 0x1f);
    pcVar1 = (char *)(**(code **)(in_EAX + 0x26b48d))();
    *pcVar1 = *pcVar1 + (char)pcVar1;
    *(char *)(unaff_EBX + -0x72f7dbac) = *(char *)(unaff_EBX + -0x72f7dbac) + extraout_CL;
    // WARNING: Bad instruction - Truncating control flow here
    halt_baddata();
}
